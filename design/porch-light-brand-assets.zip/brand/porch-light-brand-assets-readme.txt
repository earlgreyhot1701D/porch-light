PORCH LIGHT BRAND ASSETS

Primary mark
porch-light-logo.svg
Vector mark with a transparent background. Use on dark surfaces.

PNG mark
porch-light-logo-transparent-1024.png
Large transparent PNG for presentations and design tools.

Logo lockup
porch-light-logo-lockup-dark.svg
porch-light-logo-lockup-dark.png
Product name, tagline, and mark on the approved dark background.

Favicons
porch-light-favicon.svg
porch-light-favicon.ico
porch-light-favicon-32.png
porch-light-apple-touch-icon.png
porch-light-favicon-512.png

Recommended HTML
<link rel="icon" href="porch-light-favicon.svg" type="image/svg+xml">
<link rel="icon" href="porch-light-favicon-32.png" type="image/png" sizes="32x32">
<link rel="apple-touch-icon" href="porch-light-apple-touch-icon.png" sizes="180x180">
